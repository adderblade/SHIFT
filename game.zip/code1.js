gdjs.controlsCode = {};
gdjs.controlsCode.localVariables = [];
gdjs.controlsCode.GDSTARTObjects1= [];
gdjs.controlsCode.GDSTARTObjects2= [];
gdjs.controlsCode.GDCONTROLSObjects1= [];
gdjs.controlsCode.GDCONTROLSObjects2= [];
gdjs.controlsCode.GDcontrolsObjects1= [];
gdjs.controlsCode.GDcontrolsObjects2= [];
gdjs.controlsCode.GDcrowObjects1= [];
gdjs.controlsCode.GDcrowObjects2= [];
gdjs.controlsCode.GDshiftObjects1= [];
gdjs.controlsCode.GDshiftObjects2= [];
gdjs.controlsCode.GDredtileObjects1= [];
gdjs.controlsCode.GDredtileObjects2= [];
gdjs.controlsCode.GDwertileObjects1= [];
gdjs.controlsCode.GDwertileObjects2= [];
gdjs.controlsCode.GDemeraldObjects1= [];
gdjs.controlsCode.GDemeraldObjects2= [];
gdjs.controlsCode.GDbarrierObjects1= [];
gdjs.controlsCode.GDbarrierObjects2= [];
gdjs.controlsCode.GDmedalObjects1= [];
gdjs.controlsCode.GDmedalObjects2= [];
gdjs.controlsCode.GDshadowObjects1= [];
gdjs.controlsCode.GDshadowObjects2= [];
gdjs.controlsCode.GDtimerObjects1= [];
gdjs.controlsCode.GDtimerObjects2= [];
gdjs.controlsCode.GDspikeObjects1= [];
gdjs.controlsCode.GDspikeObjects2= [];


gdjs.controlsCode.eventsList0 = function(runtimeScene) {

{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "m");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "startscreen", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "l");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "levelscreen", false);
}}

}


};

gdjs.controlsCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.controlsCode.GDSTARTObjects1.length = 0;
gdjs.controlsCode.GDSTARTObjects2.length = 0;
gdjs.controlsCode.GDCONTROLSObjects1.length = 0;
gdjs.controlsCode.GDCONTROLSObjects2.length = 0;
gdjs.controlsCode.GDcontrolsObjects1.length = 0;
gdjs.controlsCode.GDcontrolsObjects2.length = 0;
gdjs.controlsCode.GDcrowObjects1.length = 0;
gdjs.controlsCode.GDcrowObjects2.length = 0;
gdjs.controlsCode.GDshiftObjects1.length = 0;
gdjs.controlsCode.GDshiftObjects2.length = 0;
gdjs.controlsCode.GDredtileObjects1.length = 0;
gdjs.controlsCode.GDredtileObjects2.length = 0;
gdjs.controlsCode.GDwertileObjects1.length = 0;
gdjs.controlsCode.GDwertileObjects2.length = 0;
gdjs.controlsCode.GDemeraldObjects1.length = 0;
gdjs.controlsCode.GDemeraldObjects2.length = 0;
gdjs.controlsCode.GDbarrierObjects1.length = 0;
gdjs.controlsCode.GDbarrierObjects2.length = 0;
gdjs.controlsCode.GDmedalObjects1.length = 0;
gdjs.controlsCode.GDmedalObjects2.length = 0;
gdjs.controlsCode.GDshadowObjects1.length = 0;
gdjs.controlsCode.GDshadowObjects2.length = 0;
gdjs.controlsCode.GDtimerObjects1.length = 0;
gdjs.controlsCode.GDtimerObjects2.length = 0;
gdjs.controlsCode.GDspikeObjects1.length = 0;
gdjs.controlsCode.GDspikeObjects2.length = 0;

gdjs.controlsCode.eventsList0(runtimeScene);
gdjs.controlsCode.GDSTARTObjects1.length = 0;
gdjs.controlsCode.GDSTARTObjects2.length = 0;
gdjs.controlsCode.GDCONTROLSObjects1.length = 0;
gdjs.controlsCode.GDCONTROLSObjects2.length = 0;
gdjs.controlsCode.GDcontrolsObjects1.length = 0;
gdjs.controlsCode.GDcontrolsObjects2.length = 0;
gdjs.controlsCode.GDcrowObjects1.length = 0;
gdjs.controlsCode.GDcrowObjects2.length = 0;
gdjs.controlsCode.GDshiftObjects1.length = 0;
gdjs.controlsCode.GDshiftObjects2.length = 0;
gdjs.controlsCode.GDredtileObjects1.length = 0;
gdjs.controlsCode.GDredtileObjects2.length = 0;
gdjs.controlsCode.GDwertileObjects1.length = 0;
gdjs.controlsCode.GDwertileObjects2.length = 0;
gdjs.controlsCode.GDemeraldObjects1.length = 0;
gdjs.controlsCode.GDemeraldObjects2.length = 0;
gdjs.controlsCode.GDbarrierObjects1.length = 0;
gdjs.controlsCode.GDbarrierObjects2.length = 0;
gdjs.controlsCode.GDmedalObjects1.length = 0;
gdjs.controlsCode.GDmedalObjects2.length = 0;
gdjs.controlsCode.GDshadowObjects1.length = 0;
gdjs.controlsCode.GDshadowObjects2.length = 0;
gdjs.controlsCode.GDtimerObjects1.length = 0;
gdjs.controlsCode.GDtimerObjects2.length = 0;
gdjs.controlsCode.GDspikeObjects1.length = 0;
gdjs.controlsCode.GDspikeObjects2.length = 0;


return;

}

gdjs['controlsCode'] = gdjs.controlsCode;
