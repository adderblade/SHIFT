gdjs.leveloneCode = {};
gdjs.leveloneCode.localVariables = [];
gdjs.leveloneCode.GDtimesObjects1= [];
gdjs.leveloneCode.GDtimesObjects2= [];
gdjs.leveloneCode.GDdoneObjects1= [];
gdjs.leveloneCode.GDdoneObjects2= [];
gdjs.leveloneCode.GDcrowObjects1= [];
gdjs.leveloneCode.GDcrowObjects2= [];
gdjs.leveloneCode.GDshiftObjects1= [];
gdjs.leveloneCode.GDshiftObjects2= [];
gdjs.leveloneCode.GDredtileObjects1= [];
gdjs.leveloneCode.GDredtileObjects2= [];
gdjs.leveloneCode.GDwertileObjects1= [];
gdjs.leveloneCode.GDwertileObjects2= [];
gdjs.leveloneCode.GDemeraldObjects1= [];
gdjs.leveloneCode.GDemeraldObjects2= [];
gdjs.leveloneCode.GDbarrierObjects1= [];
gdjs.leveloneCode.GDbarrierObjects2= [];
gdjs.leveloneCode.GDmedalObjects1= [];
gdjs.leveloneCode.GDmedalObjects2= [];
gdjs.leveloneCode.GDshadowObjects1= [];
gdjs.leveloneCode.GDshadowObjects2= [];
gdjs.leveloneCode.GDtimerObjects1= [];
gdjs.leveloneCode.GDtimerObjects2= [];
gdjs.leveloneCode.GDspikeObjects1= [];
gdjs.leveloneCode.GDspikeObjects2= [];


gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects = Hashtable.newFrom({"barrier": gdjs.leveloneCode.GDbarrierObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects = Hashtable.newFrom({"barrier": gdjs.leveloneCode.GDbarrierObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects = Hashtable.newFrom({"barrier": gdjs.leveloneCode.GDbarrierObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects = Hashtable.newFrom({"barrier": gdjs.leveloneCode.GDbarrierObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects = Hashtable.newFrom({"barrier": gdjs.leveloneCode.GDbarrierObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDshiftObjects1Objects = Hashtable.newFrom({"shift": gdjs.leveloneCode.GDshiftObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDcrowObjects1Objects = Hashtable.newFrom({"crow": gdjs.leveloneCode.GDcrowObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDshiftObjects1Objects = Hashtable.newFrom({"shift": gdjs.leveloneCode.GDshiftObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDcrowObjects1Objects = Hashtable.newFrom({"crow": gdjs.leveloneCode.GDcrowObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects = Hashtable.newFrom({"barrier": gdjs.leveloneCode.GDbarrierObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects = Hashtable.newFrom({"barrier": gdjs.leveloneCode.GDbarrierObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects = Hashtable.newFrom({"barrier": gdjs.leveloneCode.GDbarrierObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects = Hashtable.newFrom({"barrier": gdjs.leveloneCode.GDbarrierObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDshiftObjects1Objects = Hashtable.newFrom({"shift": gdjs.leveloneCode.GDshiftObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDcrowObjects1Objects = Hashtable.newFrom({"crow": gdjs.leveloneCode.GDcrowObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects = Hashtable.newFrom({"barrier": gdjs.leveloneCode.GDbarrierObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects = Hashtable.newFrom({"barrier": gdjs.leveloneCode.GDbarrierObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects = Hashtable.newFrom({"barrier": gdjs.leveloneCode.GDbarrierObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDshiftObjects1Objects = Hashtable.newFrom({"shift": gdjs.leveloneCode.GDshiftObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDcrowObjects1Objects = Hashtable.newFrom({"crow": gdjs.leveloneCode.GDcrowObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects = Hashtable.newFrom({"barrier": gdjs.leveloneCode.GDbarrierObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects = Hashtable.newFrom({"barrier": gdjs.leveloneCode.GDbarrierObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDshiftObjects1Objects = Hashtable.newFrom({"shift": gdjs.leveloneCode.GDshiftObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDcrowObjects1Objects = Hashtable.newFrom({"crow": gdjs.leveloneCode.GDcrowObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects = Hashtable.newFrom({"barrier": gdjs.leveloneCode.GDbarrierObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDshiftObjects1Objects = Hashtable.newFrom({"shift": gdjs.leveloneCode.GDshiftObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDcrowObjects1Objects = Hashtable.newFrom({"crow": gdjs.leveloneCode.GDcrowObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDcrowObjects1Objects = Hashtable.newFrom({"crow": gdjs.leveloneCode.GDcrowObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDemeraldObjects1Objects = Hashtable.newFrom({"emerald": gdjs.leveloneCode.GDemeraldObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDmedalObjects1Objects = Hashtable.newFrom({"medal": gdjs.leveloneCode.GDmedalObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDtimesObjects1Objects = Hashtable.newFrom({"times": gdjs.leveloneCode.GDtimesObjects1});
gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDdoneObjects1Objects = Hashtable.newFrom({"done": gdjs.leveloneCode.GDdoneObjects1});
gdjs.leveloneCode.eventsList0 = function(runtimeScene) {

{



}


{


let isConditionTrue_0 = false;
{
gdjs.copyArray(runtimeScene.getObjects("crow"), gdjs.leveloneCode.GDcrowObjects1);
gdjs.copyArray(runtimeScene.getObjects("done"), gdjs.leveloneCode.GDdoneObjects1);
gdjs.copyArray(runtimeScene.getObjects("medal"), gdjs.leveloneCode.GDmedalObjects1);
gdjs.copyArray(runtimeScene.getObjects("timer"), gdjs.leveloneCode.GDtimerObjects1);
gdjs.copyArray(runtimeScene.getObjects("times"), gdjs.leveloneCode.GDtimesObjects1);
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1, "", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs.leveloneCode.GDcrowObjects1.length !== 0 ? gdjs.leveloneCode.GDcrowObjects1[0] : null), true, "", 0);
}{for(var i = 0, len = gdjs.leveloneCode.GDtimerObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDtimerObjects1[i].getBehavior("Text").setText(gdjs.evtTools.common.toString(gdjs.evtTools.common.trunc(gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSeconds(runtimeScene, "TIMER") * 100) / 100));
}
}{for(var i = 0, len = gdjs.leveloneCode.GDmedalObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDmedalObjects1[i].setCenterPositionInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0),gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0));
}
}{for(var i = 0, len = gdjs.leveloneCode.GDmedalObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDmedalObjects1[i].getBehavior("Scale").setScale(2);
}
}{for(var i = 0, len = gdjs.leveloneCode.GDtimesObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDtimesObjects1[i].setCenterPositionInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0),gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) + 200);
}
}{for(var i = 0, len = gdjs.leveloneCode.GDdoneObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDdoneObjects1[i].setCenterPositionInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0),gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) + 280);
}
}{for(var i = 0, len = gdjs.leveloneCode.GDdoneObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDdoneObjects1[i].getBehavior("Scale").setScale(2);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "l");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "levelscreen", false);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "m");
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "startscreen", false);
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "d");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("crow"), gdjs.leveloneCode.GDcrowObjects1);
{for(var i = 0, len = gdjs.leveloneCode.GDcrowObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("PlatformerObject").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.leveloneCode.GDcrowObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("Flippable").flipX(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Right");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("crow"), gdjs.leveloneCode.GDcrowObjects1);
{for(var i = 0, len = gdjs.leveloneCode.GDcrowObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("PlatformerObject").simulateControl("Right");
}
}{for(var i = 0, len = gdjs.leveloneCode.GDcrowObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("Flippable").flipX(false);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "a");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("crow"), gdjs.leveloneCode.GDcrowObjects1);
{for(var i = 0, len = gdjs.leveloneCode.GDcrowObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("PlatformerObject").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.leveloneCode.GDcrowObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("Flippable").flipX(true);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Left");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("crow"), gdjs.leveloneCode.GDcrowObjects1);
{for(var i = 0, len = gdjs.leveloneCode.GDcrowObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("PlatformerObject").simulateControl("Left");
}
}{for(var i = 0, len = gdjs.leveloneCode.GDcrowObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("Flippable").flipX(true);
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "w");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15979516);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("crow"), gdjs.leveloneCode.GDcrowObjects1);
{for(var i = 0, len = gdjs.leveloneCode.GDcrowObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}{for(var i = 0, len = gdjs.leveloneCode.GDcrowObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("PlatformerObject").setCanJump();
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Up");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15980532);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("crow"), gdjs.leveloneCode.GDcrowObjects1);
{for(var i = 0, len = gdjs.leveloneCode.GDcrowObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("PlatformerObject").simulateControl("Jump");
}
}{for(var i = 0, len = gdjs.leveloneCode.GDcrowObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("PlatformerObject").setCanJump();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crow"), gdjs.leveloneCode.GDcrowObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.leveloneCode.GDcrowObjects1.length;i<l;++i) {
    if ( !(gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle()) ) {
        isConditionTrue_0 = true;
        gdjs.leveloneCode.GDcrowObjects1[k] = gdjs.leveloneCode.GDcrowObjects1[i];
        ++k;
    }
}
gdjs.leveloneCode.GDcrowObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.leveloneCode.GDcrowObjects1.length;i<l;++i) {
    if ( gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.leveloneCode.GDcrowObjects1[k] = gdjs.leveloneCode.GDcrowObjects1[i];
        ++k;
    }
}
gdjs.leveloneCode.GDcrowObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15981940);
}
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.leveloneCode.GDcrowObjects1 */
{for(var i = 0, len = gdjs.leveloneCode.GDcrowObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("Animation").setAnimationName("idle");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crow"), gdjs.leveloneCode.GDcrowObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.leveloneCode.GDcrowObjects1.length;i<l;++i) {
    if ( !(gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("PlatformerObject").isFalling()) ) {
        isConditionTrue_0 = true;
        gdjs.leveloneCode.GDcrowObjects1[k] = gdjs.leveloneCode.GDcrowObjects1[i];
        ++k;
    }
}
gdjs.leveloneCode.GDcrowObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15982836);
}
}
if (isConditionTrue_0) {
/* Reuse gdjs.leveloneCode.GDcrowObjects1 */
{for(var i = 0, len = gdjs.leveloneCode.GDcrowObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("Animation").setAnimationName("idle");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crow"), gdjs.leveloneCode.GDcrowObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.leveloneCode.GDcrowObjects1.length;i<l;++i) {
    if ( gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("PlatformerObject").isMovingEvenALittle() ) {
        isConditionTrue_0 = true;
        gdjs.leveloneCode.GDcrowObjects1[k] = gdjs.leveloneCode.GDcrowObjects1[i];
        ++k;
    }
}
gdjs.leveloneCode.GDcrowObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.leveloneCode.GDcrowObjects1.length;i<l;++i) {
    if ( gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("PlatformerObject").isOnFloor() ) {
        isConditionTrue_0 = true;
        gdjs.leveloneCode.GDcrowObjects1[k] = gdjs.leveloneCode.GDcrowObjects1[i];
        ++k;
    }
}
gdjs.leveloneCode.GDcrowObjects1.length = k;
}
if (isConditionTrue_0) {
/* Reuse gdjs.leveloneCode.GDcrowObjects1 */
{for(var i = 0, len = gdjs.leveloneCode.GDcrowObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("Animation").setAnimationName("walk");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crow"), gdjs.leveloneCode.GDcrowObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.leveloneCode.GDcrowObjects1.length;i<l;++i) {
    if ( gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("PlatformerObject").getCurrentFallSpeed() > 0 ) {
        isConditionTrue_0 = true;
        gdjs.leveloneCode.GDcrowObjects1[k] = gdjs.leveloneCode.GDcrowObjects1[i];
        ++k;
    }
}
gdjs.leveloneCode.GDcrowObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.leveloneCode.GDcrowObjects1 */
{for(var i = 0, len = gdjs.leveloneCode.GDcrowObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("Animation").setAnimationName("fly");
}
}}

}


{



}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(15985604);
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("redtile"), gdjs.leveloneCode.GDredtileObjects1);
gdjs.copyArray(runtimeScene.getObjects("shadow"), gdjs.leveloneCode.GDshadowObjects1);
gdjs.copyArray(runtimeScene.getObjects("wertile"), gdjs.leveloneCode.GDwertileObjects1);
gdjs.leveloneCode.GDbarrierObjects1.length = 0;

{for(var i = 0, len = gdjs.leveloneCode.GDredtileObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDredtileObjects1[i].hide();
}
}{for(var i = 0, len = gdjs.leveloneCode.GDwertileObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDwertileObjects1[i].hide(false);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SWITCH");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects, 510, 1055, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects, 510, 927, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects, 767, 799, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects, 510, 799, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects, 767, 927, "");
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "TIMER");
}{for(var i = 0, len = gdjs.leveloneCode.GDshadowObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDshadowObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crow"), gdjs.leveloneCode.GDcrowObjects1);
gdjs.copyArray(runtimeScene.getObjects("shift"), gdjs.leveloneCode.GDshiftObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 0);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDshiftObjects1Objects, gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDcrowObjects1Objects, false, runtimeScene, false);
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("redtile"), gdjs.leveloneCode.GDredtileObjects1);
/* Reuse gdjs.leveloneCode.GDshiftObjects1 */
gdjs.copyArray(runtimeScene.getObjects("wertile"), gdjs.leveloneCode.GDwertileObjects1);
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SWITCHCOOLDOWN");
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(1);
}{for(var i = 0, len = gdjs.leveloneCode.GDshiftObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDshiftObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.leveloneCode.GDredtileObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDredtileObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.leveloneCode.GDwertileObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDwertileObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("redtile"), gdjs.leveloneCode.GDredtileObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.leveloneCode.GDredtileObjects1.length;i<l;++i) {
    if ( !(gdjs.leveloneCode.GDredtileObjects1[i].isVisible()) ) {
        isConditionTrue_0 = true;
        gdjs.leveloneCode.GDredtileObjects1[k] = gdjs.leveloneCode.GDredtileObjects1[i];
        ++k;
    }
}
gdjs.leveloneCode.GDredtileObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.leveloneCode.GDredtileObjects1 */
{for(var i = 0, len = gdjs.leveloneCode.GDredtileObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDredtileObjects1[i].activateBehavior("Platform", false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("redtile"), gdjs.leveloneCode.GDredtileObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.leveloneCode.GDredtileObjects1.length;i<l;++i) {
    if ( gdjs.leveloneCode.GDredtileObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.leveloneCode.GDredtileObjects1[k] = gdjs.leveloneCode.GDredtileObjects1[i];
        ++k;
    }
}
gdjs.leveloneCode.GDredtileObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.leveloneCode.GDredtileObjects1 */
{for(var i = 0, len = gdjs.leveloneCode.GDredtileObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDredtileObjects1[i].activateBehavior("Platform", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("wertile"), gdjs.leveloneCode.GDwertileObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.leveloneCode.GDwertileObjects1.length;i<l;++i) {
    if ( !(gdjs.leveloneCode.GDwertileObjects1[i].isVisible()) ) {
        isConditionTrue_0 = true;
        gdjs.leveloneCode.GDwertileObjects1[k] = gdjs.leveloneCode.GDwertileObjects1[i];
        ++k;
    }
}
gdjs.leveloneCode.GDwertileObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.leveloneCode.GDwertileObjects1 */
{for(var i = 0, len = gdjs.leveloneCode.GDwertileObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDwertileObjects1[i].activateBehavior("Platform", false);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("wertile"), gdjs.leveloneCode.GDwertileObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.leveloneCode.GDwertileObjects1.length;i<l;++i) {
    if ( gdjs.leveloneCode.GDwertileObjects1[i].isVisible() ) {
        isConditionTrue_0 = true;
        gdjs.leveloneCode.GDwertileObjects1[k] = gdjs.leveloneCode.GDwertileObjects1[i];
        ++k;
    }
}
gdjs.leveloneCode.GDwertileObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.leveloneCode.GDwertileObjects1 */
{for(var i = 0, len = gdjs.leveloneCode.GDwertileObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDwertileObjects1[i].activateBehavior("Platform", true);
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crow"), gdjs.leveloneCode.GDcrowObjects1);
gdjs.copyArray(runtimeScene.getObjects("shift"), gdjs.leveloneCode.GDshiftObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 1);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDshiftObjects1Objects, gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDcrowObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "SWITCHCOOLDOWN") >= 0.5;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("barrier"), gdjs.leveloneCode.GDbarrierObjects1);
gdjs.copyArray(runtimeScene.getObjects("redtile"), gdjs.leveloneCode.GDredtileObjects1);
/* Reuse gdjs.leveloneCode.GDshiftObjects1 */
gdjs.copyArray(runtimeScene.getObjects("wertile"), gdjs.leveloneCode.GDwertileObjects1);
{for(var i = 0, len = gdjs.leveloneCode.GDbarrierObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDbarrierObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SWITCHCOOLDOWN");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects, 510, 927, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects, 767, 799, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects, 510, 799, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects, 767, 927, "");
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(2);
}{for(var i = 0, len = gdjs.leveloneCode.GDshiftObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDshiftObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.leveloneCode.GDwertileObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDwertileObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.leveloneCode.GDredtileObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDredtileObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crow"), gdjs.leveloneCode.GDcrowObjects1);
gdjs.copyArray(runtimeScene.getObjects("shift"), gdjs.leveloneCode.GDshiftObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 2);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDshiftObjects1Objects, gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDcrowObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "SWITCHCOOLDOWN") >= 0.5;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("barrier"), gdjs.leveloneCode.GDbarrierObjects1);
gdjs.copyArray(runtimeScene.getObjects("redtile"), gdjs.leveloneCode.GDredtileObjects1);
/* Reuse gdjs.leveloneCode.GDshiftObjects1 */
gdjs.copyArray(runtimeScene.getObjects("wertile"), gdjs.leveloneCode.GDwertileObjects1);
{for(var i = 0, len = gdjs.leveloneCode.GDbarrierObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDbarrierObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SWITCHCOOLDOWN");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects, 510, 927, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects, 767, 799, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects, 510, 799, "");
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(3);
}{for(var i = 0, len = gdjs.leveloneCode.GDshiftObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDshiftObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.leveloneCode.GDredtileObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDredtileObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.leveloneCode.GDwertileObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDwertileObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crow"), gdjs.leveloneCode.GDcrowObjects1);
gdjs.copyArray(runtimeScene.getObjects("shift"), gdjs.leveloneCode.GDshiftObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 3);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDshiftObjects1Objects, gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDcrowObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "SWITCHCOOLDOWN") >= 0.5;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("barrier"), gdjs.leveloneCode.GDbarrierObjects1);
gdjs.copyArray(runtimeScene.getObjects("redtile"), gdjs.leveloneCode.GDredtileObjects1);
/* Reuse gdjs.leveloneCode.GDshiftObjects1 */
gdjs.copyArray(runtimeScene.getObjects("wertile"), gdjs.leveloneCode.GDwertileObjects1);
{for(var i = 0, len = gdjs.leveloneCode.GDbarrierObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDbarrierObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SWITCHCOOLDOWN");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects, 767, 799, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects, 510, 799, "");
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(4);
}{for(var i = 0, len = gdjs.leveloneCode.GDshiftObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDshiftObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.leveloneCode.GDwertileObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDwertileObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.leveloneCode.GDredtileObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDredtileObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crow"), gdjs.leveloneCode.GDcrowObjects1);
gdjs.copyArray(runtimeScene.getObjects("shift"), gdjs.leveloneCode.GDshiftObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 4);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDshiftObjects1Objects, gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDcrowObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "SWITCHCOOLDOWN") >= 0.5;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("barrier"), gdjs.leveloneCode.GDbarrierObjects1);
gdjs.copyArray(runtimeScene.getObjects("redtile"), gdjs.leveloneCode.GDredtileObjects1);
/* Reuse gdjs.leveloneCode.GDshiftObjects1 */
gdjs.copyArray(runtimeScene.getObjects("wertile"), gdjs.leveloneCode.GDwertileObjects1);
{for(var i = 0, len = gdjs.leveloneCode.GDbarrierObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDbarrierObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SWITCHCOOLDOWN");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDbarrierObjects1Objects, 510, 799, "");
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(5);
}{for(var i = 0, len = gdjs.leveloneCode.GDshiftObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDshiftObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.leveloneCode.GDredtileObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDredtileObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.leveloneCode.GDwertileObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDwertileObjects1[i].hide();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("crow"), gdjs.leveloneCode.GDcrowObjects1);
gdjs.copyArray(runtimeScene.getObjects("shift"), gdjs.leveloneCode.GDshiftObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getScene().getVariables().getFromIndex(0).getAsNumber() == 5);
}
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDshiftObjects1Objects, gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDcrowObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "SWITCHCOOLDOWN") >= 0.5;
}
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("barrier"), gdjs.leveloneCode.GDbarrierObjects1);
gdjs.copyArray(runtimeScene.getObjects("redtile"), gdjs.leveloneCode.GDredtileObjects1);
/* Reuse gdjs.leveloneCode.GDshiftObjects1 */
gdjs.copyArray(runtimeScene.getObjects("wertile"), gdjs.leveloneCode.GDwertileObjects1);
{for(var i = 0, len = gdjs.leveloneCode.GDbarrierObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDbarrierObjects1[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "SWITCHCOOLDOWN");
}{runtimeScene.getScene().getVariables().getFromIndex(0).setNumber(0);
}{for(var i = 0, len = gdjs.leveloneCode.GDshiftObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDshiftObjects1[i].deleteFromScene(runtimeScene);
}
}{for(var i = 0, len = gdjs.leveloneCode.GDwertileObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDwertileObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.leveloneCode.GDredtileObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDredtileObjects1[i].hide();
}
}}

}


{



}


{

gdjs.copyArray(runtimeScene.getObjects("crow"), gdjs.leveloneCode.GDcrowObjects1);
gdjs.copyArray(runtimeScene.getObjects("emerald"), gdjs.leveloneCode.GDemeraldObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDcrowObjects1Objects, gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDemeraldObjects1Objects, false, runtimeScene, false);
if (isConditionTrue_0) {
/* Reuse gdjs.leveloneCode.GDcrowObjects1 */
gdjs.copyArray(runtimeScene.getObjects("shadow"), gdjs.leveloneCode.GDshadowObjects1);
{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "TIMER");
}{for(var i = 0, len = gdjs.leveloneCode.GDcrowObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDcrowObjects1[i].getBehavior("PlatformerObject").setAcceleration(0);
}
}{for(var i = 0, len = gdjs.leveloneCode.GDshadowObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDshadowObjects1[i].hide(false);
}
}{for(var i = 0, len = gdjs.leveloneCode.GDshadowObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDshadowObjects1[i].setCenterPositionInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0),gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0));
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.timerPaused(runtimeScene, "TIMER");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = runtimeScene.getOnceTriggers().triggerOnce(16004588);
}
}
if (isConditionTrue_0) {
gdjs.leveloneCode.GDdoneObjects1.length = 0;

gdjs.leveloneCode.GDmedalObjects1.length = 0;

gdjs.leveloneCode.GDtimesObjects1.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDmedalObjects1Objects, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) + 200, "");
}{for(var i = 0, len = gdjs.leveloneCode.GDmedalObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDmedalObjects1[i].getBehavior("Animation").setAnimationName("silver");
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDtimesObjects1Objects, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) + 200, "");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.leveloneCode.mapOfGDgdjs_9546leveloneCode_9546GDdoneObjects1Objects, gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0), gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) + 280, "");
}{runtimeScene.getGame().getVariables().getFromIndex(1).setString("complete");
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.timerPaused(runtimeScene, "TIMER");
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("medal"), gdjs.leveloneCode.GDmedalObjects1);
gdjs.copyArray(runtimeScene.getObjects("timer"), gdjs.leveloneCode.GDtimerObjects1);
{for(var i = 0, len = gdjs.leveloneCode.GDtimerObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDtimerObjects1[i].setCenterPositionInScene(gdjs.evtTools.camera.getCameraX(runtimeScene, "", 0),gdjs.evtTools.camera.getCameraY(runtimeScene, "", 0) + 100);
}
}{for(var i = 0, len = gdjs.leveloneCode.GDmedalObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDmedalObjects1[i].getBehavior("Animation").setAnimationName("silver");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.timerPaused(runtimeScene, "TIMER");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "TIMER") > 20;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("medal"), gdjs.leveloneCode.GDmedalObjects1);
{for(var i = 0, len = gdjs.leveloneCode.GDmedalObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDmedalObjects1[i].getBehavior("Animation").setAnimationName("bronze");
}
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.timerPaused(runtimeScene, "TIMER");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "TIMER") <= 18;
}
if (isConditionTrue_0) {
gdjs.copyArray(runtimeScene.getObjects("medal"), gdjs.leveloneCode.GDmedalObjects1);
{for(var i = 0, len = gdjs.leveloneCode.GDmedalObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDmedalObjects1[i].getBehavior("Animation").setAnimationName("gold");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("medal"), gdjs.leveloneCode.GDmedalObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.timerPaused(runtimeScene, "TIMER");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.leveloneCode.GDmedalObjects1.length;i<l;++i) {
    if ( gdjs.leveloneCode.GDmedalObjects1[i].getBehavior("Animation").getAnimationName() == "bronze" ) {
        isConditionTrue_0 = true;
        gdjs.leveloneCode.GDmedalObjects1[k] = gdjs.leveloneCode.GDmedalObjects1[i];
        ++k;
    }
}
gdjs.leveloneCode.GDmedalObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() == 4);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(3);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("medal"), gdjs.leveloneCode.GDmedalObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.timerPaused(runtimeScene, "TIMER");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.leveloneCode.GDmedalObjects1.length;i<l;++i) {
    if ( gdjs.leveloneCode.GDmedalObjects1[i].getBehavior("Animation").getAnimationName() == "silver" ) {
        isConditionTrue_0 = true;
        gdjs.leveloneCode.GDmedalObjects1[k] = gdjs.leveloneCode.GDmedalObjects1[i];
        ++k;
    }
}
gdjs.leveloneCode.GDmedalObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() == 4);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(2);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("medal"), gdjs.leveloneCode.GDmedalObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.timerPaused(runtimeScene, "TIMER");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.leveloneCode.GDmedalObjects1.length;i<l;++i) {
    if ( gdjs.leveloneCode.GDmedalObjects1[i].getBehavior("Animation").getAnimationName() == "silver" ) {
        isConditionTrue_0 = true;
        gdjs.leveloneCode.GDmedalObjects1[k] = gdjs.leveloneCode.GDmedalObjects1[i];
        ++k;
    }
}
gdjs.leveloneCode.GDmedalObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() == 3);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(2);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("medal"), gdjs.leveloneCode.GDmedalObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.timerPaused(runtimeScene, "TIMER");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.leveloneCode.GDmedalObjects1.length;i<l;++i) {
    if ( gdjs.leveloneCode.GDmedalObjects1[i].getBehavior("Animation").getAnimationName() == "gold" ) {
        isConditionTrue_0 = true;
        gdjs.leveloneCode.GDmedalObjects1[k] = gdjs.leveloneCode.GDmedalObjects1[i];
        ++k;
    }
}
gdjs.leveloneCode.GDmedalObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() == 4);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("medal"), gdjs.leveloneCode.GDmedalObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.timerPaused(runtimeScene, "TIMER");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.leveloneCode.GDmedalObjects1.length;i<l;++i) {
    if ( gdjs.leveloneCode.GDmedalObjects1[i].getBehavior("Animation").getAnimationName() == "gold" ) {
        isConditionTrue_0 = true;
        gdjs.leveloneCode.GDmedalObjects1[k] = gdjs.leveloneCode.GDmedalObjects1[i];
        ++k;
    }
}
gdjs.leveloneCode.GDmedalObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() == 3);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(1);
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("medal"), gdjs.leveloneCode.GDmedalObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.runtimeScene.timerPaused(runtimeScene, "TIMER");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.leveloneCode.GDmedalObjects1.length;i<l;++i) {
    if ( gdjs.leveloneCode.GDmedalObjects1[i].getBehavior("Animation").getAnimationName() == "gold" ) {
        isConditionTrue_0 = true;
        gdjs.leveloneCode.GDmedalObjects1[k] = gdjs.leveloneCode.GDmedalObjects1[i];
        ++k;
    }
}
gdjs.leveloneCode.GDmedalObjects1.length = k;
if (isConditionTrue_0) {
isConditionTrue_0 = false;
{isConditionTrue_0 = (runtimeScene.getGame().getVariables().getFromIndex(0).getAsNumber() == 2);
}
}
}
if (isConditionTrue_0) {
{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(1);
}}

}


{


let isConditionTrue_0 = false;
isConditionTrue_0 = false;
isConditionTrue_0 = gdjs.evtTools.input.isKeyPressed(runtimeScene, "r");
if (isConditionTrue_0) {
isConditionTrue_0 = false;
isConditionTrue_0 = !(gdjs.evtTools.runtimeScene.timerPaused(runtimeScene, "TIMER"));
}
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.pushScene(runtimeScene, "levelone");
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("done"), gdjs.leveloneCode.GDdoneObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.leveloneCode.GDdoneObjects1.length;i<l;++i) {
    if ( gdjs.leveloneCode.GDdoneObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.leveloneCode.GDdoneObjects1[k] = gdjs.leveloneCode.GDdoneObjects1[i];
        ++k;
    }
}
gdjs.leveloneCode.GDdoneObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.leveloneCode.GDdoneObjects1 */
{for(var i = 0, len = gdjs.leveloneCode.GDdoneObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDdoneObjects1[i].getBehavior("Animation").setAnimationName("hover");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("done"), gdjs.leveloneCode.GDdoneObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.leveloneCode.GDdoneObjects1.length;i<l;++i) {
    if ( !(gdjs.leveloneCode.GDdoneObjects1[i].getBehavior("ButtonFSM").IsHovered((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined))) ) {
        isConditionTrue_0 = true;
        gdjs.leveloneCode.GDdoneObjects1[k] = gdjs.leveloneCode.GDdoneObjects1[i];
        ++k;
    }
}
gdjs.leveloneCode.GDdoneObjects1.length = k;
if (isConditionTrue_0) {
/* Reuse gdjs.leveloneCode.GDdoneObjects1 */
{for(var i = 0, len = gdjs.leveloneCode.GDdoneObjects1.length ;i < len;++i) {
    gdjs.leveloneCode.GDdoneObjects1[i].getBehavior("Animation").setAnimationName("static");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("done"), gdjs.leveloneCode.GDdoneObjects1);

let isConditionTrue_0 = false;
isConditionTrue_0 = false;
for (var i = 0, k = 0, l = gdjs.leveloneCode.GDdoneObjects1.length;i<l;++i) {
    if ( gdjs.leveloneCode.GDdoneObjects1[i].getBehavior("ButtonFSM").IsClicked((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined)) ) {
        isConditionTrue_0 = true;
        gdjs.leveloneCode.GDdoneObjects1[k] = gdjs.leveloneCode.GDdoneObjects1[i];
        ++k;
    }
}
gdjs.leveloneCode.GDdoneObjects1.length = k;
if (isConditionTrue_0) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "levelscreen", false);
}}

}


};

gdjs.leveloneCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.leveloneCode.GDtimesObjects1.length = 0;
gdjs.leveloneCode.GDtimesObjects2.length = 0;
gdjs.leveloneCode.GDdoneObjects1.length = 0;
gdjs.leveloneCode.GDdoneObjects2.length = 0;
gdjs.leveloneCode.GDcrowObjects1.length = 0;
gdjs.leveloneCode.GDcrowObjects2.length = 0;
gdjs.leveloneCode.GDshiftObjects1.length = 0;
gdjs.leveloneCode.GDshiftObjects2.length = 0;
gdjs.leveloneCode.GDredtileObjects1.length = 0;
gdjs.leveloneCode.GDredtileObjects2.length = 0;
gdjs.leveloneCode.GDwertileObjects1.length = 0;
gdjs.leveloneCode.GDwertileObjects2.length = 0;
gdjs.leveloneCode.GDemeraldObjects1.length = 0;
gdjs.leveloneCode.GDemeraldObjects2.length = 0;
gdjs.leveloneCode.GDbarrierObjects1.length = 0;
gdjs.leveloneCode.GDbarrierObjects2.length = 0;
gdjs.leveloneCode.GDmedalObjects1.length = 0;
gdjs.leveloneCode.GDmedalObjects2.length = 0;
gdjs.leveloneCode.GDshadowObjects1.length = 0;
gdjs.leveloneCode.GDshadowObjects2.length = 0;
gdjs.leveloneCode.GDtimerObjects1.length = 0;
gdjs.leveloneCode.GDtimerObjects2.length = 0;
gdjs.leveloneCode.GDspikeObjects1.length = 0;
gdjs.leveloneCode.GDspikeObjects2.length = 0;

gdjs.leveloneCode.eventsList0(runtimeScene);
gdjs.leveloneCode.GDtimesObjects1.length = 0;
gdjs.leveloneCode.GDtimesObjects2.length = 0;
gdjs.leveloneCode.GDdoneObjects1.length = 0;
gdjs.leveloneCode.GDdoneObjects2.length = 0;
gdjs.leveloneCode.GDcrowObjects1.length = 0;
gdjs.leveloneCode.GDcrowObjects2.length = 0;
gdjs.leveloneCode.GDshiftObjects1.length = 0;
gdjs.leveloneCode.GDshiftObjects2.length = 0;
gdjs.leveloneCode.GDredtileObjects1.length = 0;
gdjs.leveloneCode.GDredtileObjects2.length = 0;
gdjs.leveloneCode.GDwertileObjects1.length = 0;
gdjs.leveloneCode.GDwertileObjects2.length = 0;
gdjs.leveloneCode.GDemeraldObjects1.length = 0;
gdjs.leveloneCode.GDemeraldObjects2.length = 0;
gdjs.leveloneCode.GDbarrierObjects1.length = 0;
gdjs.leveloneCode.GDbarrierObjects2.length = 0;
gdjs.leveloneCode.GDmedalObjects1.length = 0;
gdjs.leveloneCode.GDmedalObjects2.length = 0;
gdjs.leveloneCode.GDshadowObjects1.length = 0;
gdjs.leveloneCode.GDshadowObjects2.length = 0;
gdjs.leveloneCode.GDtimerObjects1.length = 0;
gdjs.leveloneCode.GDtimerObjects2.length = 0;
gdjs.leveloneCode.GDspikeObjects1.length = 0;
gdjs.leveloneCode.GDspikeObjects2.length = 0;


return;

}

gdjs['leveloneCode'] = gdjs.leveloneCode;
